package Player;
import config.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Pair;


public class Player {
	
	private Direction direction;
	private Sprite sprite;
	private Pair<Integer, Integer> position;
	 
	 private ImageView image = new ImageView();
	 private static final String NAME = "EVALINA";
	 
	 private static final Player INSTANCE = new Player();
	 
	    public Pair<Integer, Integer> getPosition(){
	        return this.position;
	    }
	    public void setDirection(Direction up) {
			this.direction = up;
		}
		public Direction getDirection() {
	        return this.direction;
	    }

	    public Sprite getSprite() {
	        return this.sprite;
	    }
	    
	    public ImageView getImage() {
	        return this.image;
	    }
	    
	    public static Player getINSTANCE() {
	        return Player.INSTANCE;
	    }

	    public void setImage(ImageView image) {
	        this.image = image;
	    }
	    
	    public void setSprite(final Sprite sprite) {
	        this.sprite = sprite;
	        this.image.setImage(new Image(this.sprite.getSpritePath()));
	        this.image.setPreserveRatio(true);
	        this.image.setFitWidth(50);
	    }
	    public void setPosition(final Pair<Integer, Integer> position) {
	        this.position = position;
	    }
		public void setPlayerOnTop(int nbMap) {
		       MapConfig.getINSTANCE().getMaps().get(nbMap).getGridPane().getChildren().remove(this.image);
		        MapConfig.getINSTANCE().getMaps().get(nbMap).getGridPane().getChildren().add(this.image);			
		}

	    
	 
}

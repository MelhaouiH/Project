package classes;

import Config.DialogPanel;
import Config.Inter;

import config.Interaction;

import config.Sprite;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import lib.Inventory;
import lib.MainLayout;
import javafx.scene.layout.GridPane;

import javafx.scene.layout.Pane;
import javafx.scene.layout.RowConstraints;


public class Layout {
				//DIMENSIONS
			   private int nbCols;
			   private int nbRows;
			  
			   private  static  final int WIDTH = 2000;
			    private  static final int HEIGHT = 700;
			    private  final static Layout INSTANCE = new Layout();
				private GridPane gridPane;
			    private static final Stage STAGE = new Stage();
			    private Pane pane;

	    
	    private static final Scene SCENE = new Scene(new Parent(){}, WIDTH, HEIGHT);
	    public Layout() {
	        Layout.STAGE.setScene(Layout.SCENE);
	        Layout.getScene().getStylesheets().add("config/style.css");
	        Layout.STAGE.getIcons().add(new Image(Sprite.PLAYER_DOWN_STOP.getSpritePath()));
	        this.gridPane = Layout();
	        this.nbCols = 30;
	        this.nbRows = 10;
	        this.gridPane = new GridPane();
	        this.pane = new Pane();
	        GridPane.setColumnSpan(this.pane, 2);
	        GridPane.setConstraints(this.pane, 0, 0);
	        this.pane.getChildren().add(this.gridPane);
	        this.pane.setFocusTraversable(true);
	        this.pane.requestFocus();
	    }
		public static int getWidth() {
			return WIDTH;
		}
		public static int getHeight() {
			return HEIGHT;
		}
		public static Scene getScene() {
			return SCENE;
		}
	    public static Stage getSTAGE() {
	        return Layout.STAGE;
	    }


	    public static Layout getINSTANCE() {
	        return Layout.INSTANCE;
	    }

	    private static GridPane Layout(){
	        GridPane gridPane = new GridPane();
	        GridPane inventoryLayout = Layout.inventoryLayout();
	        GridPane dialogLayout =DialogPanel.getINSTANCE().getGridPane();

	        gridPane.getColumnConstraints().add(new ColumnConstraints(  (float)Layout.WIDTH*2/3));
	        gridPane.getColumnConstraints().add(new ColumnConstraints(  (float)Layout.WIDTH/3));
	        gridPane.getRowConstraints().add(new RowConstraints(  (float)Layout.HEIGHT*2/3));
	        gridPane.getRowConstraints().add(new RowConstraints(  (float)Layout.HEIGHT/3));
	        GridPane.setConstraints(inventoryLayout, 1, 1);
	        GridPane.setConstraints(dialogLayout, 0, 1);
	        gridPane.getChildren().addAll(Layout.getINSTANCE().getPane(), inventoryLayout, dialogLayout);

	        return gridPane;
	    }

	    public int getNbCols() {
	        return this.nbCols;
	    }
	    private static GridPane inventoryLayout(){ 
	        return Inventory.getINSTANCE().getGridPane();
	    }


	    public int getNbRows() { 
	        return this.nbRows;
	    }


	    public Pane getPane() {
	        return this.pane;
	    }
	    public GridPane getGridPane() {
	        Layout.getScene().removeEventHandler(KeyEvent.KEY_PRESSED, Inter.RETURN_GAME.getEventHandler());
	        return this.gridPane;
	    }
		public Parent getvBox() {
			
			return null;
		}
		public void setGrid(GridPane grid) {
			// TODO Auto-generated method stub
			
		}


}

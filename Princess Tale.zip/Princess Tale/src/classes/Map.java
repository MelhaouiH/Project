package classes;
import java.util.ArrayList;


import javafx.scene.layout.GridPane;

import javafx.util.Pair;
import config.*;
import java.util.Iterator;
import java.util.List;




//Classes represantant les cartes du jeu 

public class Map implements Iterable<Cell> {
	
    private GridPane grid;
    private List<Cell> cells = new ArrayList<>();
    private ParticularIterator<Block> blockIterator = new ParticularIterator<Block>(Block.class, this.cells);
    private ParticularIterator<TransitionCell> transitionCellIterator = new ParticularIterator<>(TransitionCell.class, this.cells);
    public Map() {
        this.grid = new GridPane();
    }
    public void add(Cell cell){

        this.cells.add(cell);
        GridPane.setConstraints(cell.getImage(), cell.getPosition().getKey(), cell.getPosition().getValue());
        this.getGrid().getChildren().add(cell.getImage());
    }

	public GridPane getGrid() {
		return grid;
	}
	   public ParticularIterator<Block> getBlockingCellIterator() {
	        return this.blockIterator;
	    }
	    public ParticularIterator<TransitionCell> getTransitionCellIterator() {
	        return this.transitionCellIterator;
	    }
	   
	    public void remove(Cell cell){
	        if(!this.getGrid().getChildren().contains(cell.getImage()))
	            return;
	        this.cells.remove(cell);
	        this.getGrid().getChildren().remove(cell.getImage());
	    }
	@Override
	public Iterator<Cell> iterator() {
        return this.cells.iterator();
		
	}

}

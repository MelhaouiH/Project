package classes;

import java.util.Iterator;
import java.util.List;

import classes.*;




public class ParticularIterator<T extends Cell> implements Iterator<T>{
    private List<Cell> cells;
    private Class<T> type;
    private int count=0;
    public ParticularIterator(Class<T> type, List<Cell> cells) {
        this.type = type;
        this.cells = cells;
    }
    
    @Override
    public boolean hasNext() {
        for(int i = count; i < cells.size(); ++i) {
                if (this.type.isInstance(cells.get(i))){
                    return true;
                }
        }
        this.count = 0;
        return false;
    }
    
    @Override
    public T next() {
        if (hasNext()) {
            for (int i = count; i < cells.size(); ++i) {
                if (this.type.isInstance(cells.get(i))) {
                    ++this.count;
                    return (T)cells.get(i);
                }
            }
        }
        return null;
    }
    //reinitialiser le compteur
    public void reset(){
        this.count = 0;
    }
}

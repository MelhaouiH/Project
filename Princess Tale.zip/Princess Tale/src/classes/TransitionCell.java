package classes;
import Player.Player;
import config.Direction;
import config.MapArrangement;
import config.Sprite;
import javafx.event.EventHandler;
import javafx.scene.input.KeyEvent;
import javafx.util.Pair;
import main.GamePanel;
//permet au princess de changer d'un carte � une autre
public class TransitionCell extends Cell  {
    private Direction direction;
    private EventHandler<KeyEvent> eventHandler;

	public TransitionCell(Sprite sprite, Pair<Integer, Integer> position, Direction direction) {
        super(sprite, position);
        this.direction = direction;
        
        this.eventHandler = event -> {
            if(event.getCode() == this.direction.getKey().getKeyCode()){
                int i = 0;
                lib.Map nextMap = null;
                Pair<Integer, Integer> nextPosition = null;
                for(Map m : MapConfig.getInstance().getMaps()){
                    if(m.equals(Move.getMap())){
                        switch(this.direction){
                            case UP :
                                nextMap = MapArrangement.values()[i].getUp();
                                nextPosition = new Pair<>(Player.getINSTANCE().getPosition().getKey(),
                                       Layout.getINSTANCE().getNbRows() - 1);
                                break;
                            case DOWN :
                                nextMap = MapArrangement.values()[i].getDown();
                                nextPosition = new Pair<>(Player.getINSTANCE().getPosition().getKey(), 0);
                                break;
                            case RIGHT :
                                nextMap = MapArrangement.values()[i].getRight();
                                nextPosition = new Pair<>(0, Player.getINSTANCE().getPosition().getValue());
                                break;
                            case LEFT :
                                nextMap = MapArrangement.values()[i].getLeft();
                                nextPosition = new Pair<>(Layout.getINSTANCE().getNbCols() - 1,
                                        Player.getINSTANCE().getPosition().getValue());
                                break;
                        }
                        Player player = Player.getINSTANCE();

                        Move.getMap().getGrid().getChildren().remove(player.getImage());
                  

                        break;
                    }
                    ++i;
                }
            }
            Layout.getScene().removeEventHandler(KeyEvent.KEY_PRESSED, this.getEventHandler());
        };
        
	}
	
   public Direction getDirection() {
       return this.direction;
   
}
   public EventHandler<KeyEvent> getEventHandler() {
       return this.eventHandler;
   }
}

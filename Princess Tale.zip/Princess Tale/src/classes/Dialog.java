package classes;



public enum Dialog {
    /*Enumeration contenant toutes les paroles (dialogues) de tous les personnages du jeu*/
	
	//Village de d�part 
	
    Pers1("OH NON !  le prince � �t� kidnapp� et enferm� dans la plus haute salle de la plus haute tour de son ch�teau. ");
    //Chateau
	
    //Salle
    
    private String text;
    Dialog(String text) {
        this.text = text;
    }
    public String getText() {
        return this.text;
    }
	
}

package classes;

import config.Direction;
import Config.Inter;
import config.*;
import config.Sprite;
import javafx.util.Pair;

public class Block extends Cell  {
	 private Inter interaction;


	    private AnimationSet animationSet;

	    private Direction direction;

	    // Constructeur de la cellule bloquante avec son sprite ainsi que sa position, 
	    public Block(Sprite sprite, Pair<Integer, Integer> position) {
	        super(sprite, position);
	        this.interaction = null;
	        this.animationSet = AnimationSet.getAnimationSetThatHave(sprite);
	        if(this.animationSet != null)
	            this.direction = this.animationSet.getDirection(sprite);
	    }

	    public Block(Sprite sprite, Pair<Integer, Integer> position, Inter  interaction) {
	        super(sprite, position);
	        this.interaction = interaction;
	        this.animationSet = AnimationSet.getAnimationSetThatHave(sprite);
	        if(this.animationSet != null)
	            this.direction = this.animationSet.getDirection(sprite);
	    }

	    //Getter de la cellule bloquante.

	    public Inter  getInteraction() {
	        return interaction;
	    }

	    // Setter de la cellule bloquante.

	    public void setInteraction(Inter  toAdd) {
	        this.interaction = toAdd;
	    }

	    //Setter de la direction de la cellule bloquante,
	    
	    public void setDirection(Direction direction) {
	        this.direction = direction;
	        if(this.animationSet != null)
	            this.setSprite(animationSet.getSpriteDirection(direction));
	    }
	}




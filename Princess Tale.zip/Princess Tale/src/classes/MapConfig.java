package classes;


import java.util.ArrayList;


import classes.Map;

import Config.Castle;
import Config.Inter;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.util.Pair;
import classes.*;
import main.GamePanel;
import javafx.concurrent.Task;
import config.*;
import Player.*;

public class MapConfig {
    private static final MapConfig INSTANCE = new MapConfig();
    private static ArrayList<Map> maps;
    public ArrayList<Map> getMaps() {
        return maps;
    }
    private  static Task<Void> task;
    private MapConfig() {
        MapConfig.maps = new ArrayList<>();
        for(Castle castle : Castle.values()){
            for(Map map : castle.getMaps()){
                for(int i = 0; i <Layout.getINSTANCE().getNbCols(); ++i){
                    map.getGrid().getColumnConstraints().add(new ColumnConstraints((float)Layout.getWidth()/Layout.getINSTANCE().getNbCols()));
                }
                for(int i = 0 ; i < Layout.getINSTANCE().getNbRows(); ++i){
                    map.getGrid().getRowConstraints()
                            .add(new RowConstraints(  (float)Layout.getHeight()*2/3/Layout.getINSTANCE().getNbRows()));
                }
                MapConfig.maps.add(map);
            }
        }
}
	public static MapConfig getInstance() {
		return INSTANCE;
	}
	public static Task<Void> getTask() {
		return task;
	} 



    public void configMap(Map map,Pair<Integer, Integer> position){
        Move.setMap(map);
        Player player = Player.getINSTANCE();

        player.setPosition(position);
        if(player.getSprite() == null)
            player.setSprite(Sprite.PLAYER_DOWN_STOP);
        else
            player.setSprite(AnimationSet.getAnimationSetThatHave(Player.getINSTANCE().getSprite()).getSpriteDirection(player.getDirection()));
        player.setDirection(AnimationSet.getAnimationSetThatHave(player.getSprite()).getDirection(player.getSprite()));
        player.getImage().setTranslateX(0);
        player.getImage().setTranslateY(0);
        GridPane.setConstraints(player.getImage(), position.getKey(),position.getValue());

        if(map.getGrid().getChildren().contains(player.getImage()))
            map.getGrid().getChildren().remove(player.getImage());

        map.getGrid().getChildren().add(player.getImage());
        Layout.getINSTANCE().setGrid(map.getGrid());
    }
    
    public void configMap(Map map){
        Castle castle = Castle.getHallOfMap(map);
        if(castle.equals(Castle.HALL)){
            configMap(map, new Pair<>(10, 6));
        }
        if(castle.equals(Castle.CAST)){
            configMap(map, new Pair<>(10, 6));
        }
        if(castle.equals(Castle.NORTH)){
            configMap(map, new Pair<>(4, 8));
        }
        if(castle.equals(Castle.WEST)){
            configMap(map, new Pair<>(8, 9));
        }
        if(castle.equals(Castle.OUEST)){
            configMap(map, new Pair<>(24, 5));
        }
        if(castle.equals(Castle.SOUTH)){
            configMap(map, new Pair<>(2, 8));
        }
    }
    public void movePlayer(Pair<Integer, Integer> targetPosition){
        Player player = Player.getINSTANCE();
        double x = (player.getPosition().getKey() - targetPosition.getKey()) * 50;
        double y = (player.getPosition().getValue() - targetPosition.getValue()) * 50;

        Player.getINSTANCE().setPosition(targetPosition);

        ImageView imageView = player.getImage();
        imageView.setImage(new Image(player.getSprite().getSpritePath()));
        player.getImage().setTranslateX(player.getImage().getX());
        player.getImage().setTranslateY(player.getImage().getY() + y);

        GridPane.setConstraints(imageView, player.getPosition().getKey(), player.getPosition().getValue());
    }

    /**
     * Permet d'échanger deux cellules sur une carte.
     * @param nbMap carte sur laquelle on travaille
     * @param positionCell1 position de la première cellule à échanger
     * @param positionCell2 position de la deuxième cellule à échanger
     * @return boolean
     */
    public boolean swapCells(int nbMap, Pair<Integer, Integer> positionCell1, Pair<Integer, Integer> positionCell2){
        if(Player.getINSTANCE().getPosition().equals(positionCell1) || Player.getINSTANCE().getPosition().equals(positionCell2)){
            return false;
        }
        Cell firstCell1 = getFirstCell(nbMap, positionCell1.getKey(), positionCell1.getValue());
        Cell firstCell2 = getFirstCell(nbMap, positionCell2.getKey(), positionCell2.getValue());
        Cell lastCell1 = getFirstCell(nbMap, positionCell1.getKey(), positionCell1.getValue());
        Cell lastCell2 = getLastCell(nbMap, positionCell2.getKey(), positionCell2.getValue());

        if(firstCell1 != lastCell1 && firstCell2 != lastCell2 ){
            MapConfig.getInstance().getMaps().get(nbMap).getGrid().getChildren().removeAll(lastCell1.getImage(), lastCell2.getImage());

            lastCell1.setPosition(positionCell2);
            GridPane.setConstraints(lastCell1.getImage(), positionCell2.getKey(), positionCell2.getValue());

            lastCell2.setPosition(positionCell1);
            GridPane.setConstraints(lastCell2.getImage(), positionCell1.getKey(), positionCell1.getValue());

            MapConfig.getInstance().getMaps().get(nbMap).getGrid().getChildren().addAll(lastCell1.getImage(), lastCell2.getImage());
        }
        else if(firstCell1 != lastCell1){
            MapConfig.getInstance().getMaps().get(nbMap).getGrid().getChildren().remove(lastCell1.getImage());

            lastCell1.setPosition(positionCell2);
            GridPane.setConstraints(lastCell1.getImage(), positionCell2.getKey(), positionCell2.getValue());

            MapConfig.getInstance().getMaps().get(nbMap).getGrid().getChildren().add(lastCell1.getImage());
        }
        else if(firstCell2 != lastCell2){
            MapConfig.getInstance().getMaps().get(nbMap).getGrid().getChildren().remove(lastCell2.getImage());

            lastCell2.setPosition(positionCell1);
            GridPane.setConstraints(lastCell2.getImage(), positionCell1.getKey(), positionCell1.getValue());

            MapConfig.getInstance().getMaps().get(nbMap).getGrid().getChildren().add(lastCell2.getImage());
        }

        Player.getINSTANCE().setPlayerOnTop(nbMap);
        return true;
    }

	
	private Cell getFirstCell(int nbMap, Integer key, Integer value) {
		// TODO Auto-generated method stub
		return null;
	}
    private Cell getLastCell(int nbMap, Integer key, Integer value) {
		// TODO Auto-generated method stub
		return null;
	}
    private static Block addBlockingCell(Sprite sprite, Pair<Integer, Integer> position){
        return new Block(sprite, position);
    }

    private static Block addBlockingCell(Sprite sprite, Pair<Integer, Integer> position, Inter interaction){
        return new Block(sprite, position, interaction);
    }

	//Classe interne permettant la mise en place, sprite par sprite.

    private static class MapSetup{

 
        private static Block addBlockingCell(Sprite sprite, Pair<Integer, Integer> position){
            return new Block(sprite, position);
        }


 
        private static TransitionCell addTransitionCell(Sprite sprite, Pair<Integer, Integer> position, Direction direction){
            return new TransitionCell(sprite, position, direction);
        }

        /**
         * Crée une cellule classique sur laquelle Leskak peut marcher.
         * @param sprite sprite de la cellule
         * @param position position de la cellule
         * @return Cell
         */
        private static Cell addCell(Sprite sprite, Pair<Integer, Integer> position){
            return new Cell(sprite, position);
        }

        /**
         * Crée un rectangle de BlockingCell en fonction du paramètre str permettant de savoir sur quel type de "bâtiment"
         * on travaille. Par exemple, cette fonction est très utile pour le centre commercial, où il faut placer de nombreux
         * rectangles comme des buildings, voitures... étant des BlockingCell.
         * @param m carte sur laquelle on travaille
         * @param str chaîne de caractère permettant de savoir sur quels sprites on travaille
         * @param col nombre de colones du building
         * @param row nombre de lignes du building
         * @param position poisition de départ (en haut à gauche) du building
         * @param interaction intéraction avec celui-ci si elle existe
         */
        private static void createBuilding(Map m, String str, int col, int row, Pair<Integer, Integer> position, Interaction interaction){
            for(int i = 0; i < row; ++i){
                for(int j = 0; j < col; ++j){
                    if(interaction == null)
                        m.add(addBlockingCell(Sprite.valueOf(str.concat(String.valueOf(i*col + j))), new Pair<>(position.getKey() + j, position.getValue() + i)));

                }}
        }

        /**
         * Génère l'ensemble de la premi�re carte du chateau.
         */
        private static void setupMap0(){
            Map m = maps.get(0);

            for (int i = 0; i <= 31; ++i) for (int j = 0; j <= 11; ++j) m.add(addCell(Sprite.GRASS, new Pair<>(i, j)));

            for (int i = 12; i <= 14; ++i) m.add(addTransitionCell(Sprite.GRASS, new Pair<>(i, 0), Direction.UP));
            for (int j = 2; j <= 4; ++j) m.add(addTransitionCell(Sprite.GRASS, new Pair<>(31, j), Direction.RIGHT));

            for (int i = 0; i <= 11; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 0)));
            for (int i = 15; i <= 21; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 0)));
            for (int i = 25; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 0)));
            for (int i = 0; i <= 3; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 1)));
            for (int i = 17; i <= 21; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 1)));
            for (int i = 24; i <= 25; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 1)));
            for (int i = 30; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 1)));
            for (int i = 0; i <= 3; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 2)));
            for (int i = 20; i <= 21; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 2)));
            for (int i = 24; i <= 24; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 2)));
            for (int i = 0; i <= 2; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 3)));
            for (int i = 21; i <= 21; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 3)));
            for (int i = 0; i <= 2; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 4)));
            for (int i = 0; i <= 2; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 5)));
            for (int i = 31; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 5)));
            for (int i = 0; i <= 2; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 6)));
            for (int i = 23; i <= 23; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 6)));
            for (int i = 31; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 6)));
            for (int i = 0; i <= 2; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 7)));
            for (int i = 22; i <= 23; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 7)));
            for (int i = 31; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 7)));
            for (int i = 0; i <= 2; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 8)));
            for (int i = 20; i <= 23; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 8)));
            for (int i = 30; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 8)));
            for (int i = 0; i <= 3; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 9)));
            for (int i = 18; i <= 24; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 9)));
            for (int i = 29; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 9)));
            for (int i = 0; i <= 24; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 10)));
            for (int i = 27; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 10)));
            for (int i = 0; i <= 24; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 11)));
            for (int i = 27; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 11)));


            createBuilding(m, "HOUSE1_", 2, 2, new Pair<>(5, 2), null);
            createBuilding(m, "HOUSE1_", 2, 2, new Pair<>(15, 3), null);
            createBuilding(m, "HOUSE1_", 2, 2, new Pair<>(15, 7), null);

            for (int i = 23; i <= 25; ++i) m.add(addCell(Sprite.BRIDGE, new Pair<>(i, 5)));

            updateSpritesOf(0, SpriteSet.TREE_SET);
            updateSpritesOf(0, SpriteSet.WATER_SET);
        }

        /**
         * G�nere l'ensemble de la deuxi�me carte HALL.
         */
        private static void setupMap1() {
            Map m = maps.get(1);

            for (int i = 0; i <= 31; ++i) for (int j = 0; j <= 11; ++j) m.add(addCell(Sprite.GRASS, new Pair<>(i, j)));

            for (int j = 2; j <= 4; ++j) m.add(addTransitionCell(Sprite.GRASS, new Pair<>(0, j), Direction.LEFT));

 

            for (int i = 0; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 0)));
            for (int i = 0; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 1)));
            for (int i = 2; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 2)));
            for (int i = 3; i <= 11; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 3)));
            for (int i = 17; i <= 26; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 3)));
            for (int i = 30; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 3)));
            for (int i = 5; i <= 10; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 4)));
            for (int i = 18; i <= 25; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 4)));
            for (int i = 31; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 4)));
            for (int i = 0; i <= 2; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 5)));
            for (int i = 5; i <= 9; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 5)));
            for (int i = 13; i <= 14; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 5)));
            for (int i = 19; i <= 22; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 5)));
            for (int i = 31; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 5)));
            for (int i = 0; i <= 2; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 6)));
            for (int i = 5; i <= 8; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 6)));
            for (int i = 13; i <= 16; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 6)));
            for (int i = 21; i <= 21; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 6)));
            for (int i = 31; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 6)));
            for (int i = 0; i <= 3; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 7)));
            for (int i = 6; i <= 8; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 7)));
            for (int i = 11; i <= 17; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 7)));
            for (int i = 24; i <= 25; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 7)));
            for (int i = 31; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 7)));
      
        }

        /**
         *  la troisi�me carte de EST AILE.
         */
        private static void setupMap2(){
            Map m = maps.get(2);

            for (int i = 0; i <= 31; ++i) for (int j = 0; j <= 11; ++j) m.add(addCell(Sprite.GRASS, new Pair<>(i, j)));

            for (int i = 12; i <= 14; ++i) m.add(addTransitionCell(Sprite.GRASS, new Pair<>(i, 11), Direction.DOWN));

            for (int i = 0; i <= 27; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 0)));
            for (int i = 30; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 0)));
            for (int i = 0; i <= 9; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 1)));
            for (int i = 17; i <= 24; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 1)));
            for (int i = 30; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 1)));
            for (int i = 0; i <= 6; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 2)));
            for (int i = 20; i <= 24; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 2)));
            for (int i = 30; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 2)));
            for (int i = 0; i <= 5; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 3)));
            for (int i = 21; i <= 23; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 3)));
            for (int i = 28; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 3)));
            for (int i = 0; i <= 4; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 4)));
            for (int i = 22; i <= 23; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 4)));
            for (int i = 28; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 4)));
            for (int i = 0; i <= 4; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 5)));
            for (int i = 22; i <= 23; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 5)));
            for (int i = 26; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 5)));
            for (int i = 0; i <= 4; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 6)));
            for (int i = 22; i <= 23; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 6)));
            for (int i = 26; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 6)));
            for (int i = 0; i <= 5; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 7)));
            for (int i = 21; i <= 23; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 7)));
            for (int i = 26; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 7)));
            for (int i = 0; i <= 6; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 8)));
            for (int i = 20; i <= 22; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 8)));
            for (int i = 26; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 8)));
            for (int i = 0; i <= 9; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 9)));
            for (int i = 17; i <= 22; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 9)));
            for (int i = 25; i <= 31; ++i) m.add(addBlockingCell(Sprite.TREE, new Pair<>(i, 9)));

        }
        /**
         * la troisi�me carte de OUEST AILE.
         */
        private static void setupMap3(){
            Map m = maps.get(3);

            for(int i = 0; i <= 31; ++i) for(int j = 0; j <= 11; ++j) m.add(addCell(Sprite.SAND, new Pair<>(i,j)));

            for (int i = 1; i <= 1; ++i) m.add(addTransitionCell(Sprite.SAND, new Pair<>(i, 0), Direction.UP));
            for (int i = 4; i <= 4; ++i) m.add(addTransitionCell(Sprite.SAND, new Pair<>(i, 0), Direction.UP));
            for (int i = 6; i <= 6; ++i) m.add(addTransitionCell(Sprite.SAND, new Pair<>(i, 0), Direction.UP));
            for (int i = 9; i <= 9; ++i) m.add(addTransitionCell(Sprite.SAND, new Pair<>(i, 0), Direction.UP));
        
          
        }
}
        /**
         * la troisi�me carte de South AILE.
         */
       /*  private static void setupMap6(){
            Map m = maps.get(6);

            for(int i = 0; i <= 31; ++i) for(int j = 0; j <= 11; ++j) m.add(addCell(Sprite.SAND, new Pair<>(i,j)));

        
            for (int i = 11; i <= 19; ++i) m.add(addBlockingCell(Sprite.TREE2, new Pair<>(i, 9)));
            for (int i = 24; i <= 24; ++i) m.add(addBlockingCell(Sprite.TREE2, new Pair<>(i, 9)));
            for (int i = 26; i <= 28; ++i) m.add(addBlockingCell(Sprite.TREE2, new Pair<>(i, 9)));
   
        }*/

        /**
         *la troisi�me carte de NORTH AILE.
         */
      /*  private static void setupMap7(){
            Map m = maps.get(7);

            for(int i = 0; i <= 31; ++i) for(int j = 0; j <= 11; ++j) m.add(addCell(Sprite.FLOOR, new Pair<>(i,j)));

        
            for (int i = 6; i <= 6; ++i) m.add(addBlockingCell(Sprite.FLOOR_UP_LEFT, new Pair<>(i, 0)));
            for (int i = 24; i <= 24; ++i) m.add(addBlockingCell(Sprite.FLOOR_UP_RIGHT, new Pair<>(i, 0)));
            for (int i = 28; i <= 28; ++i) m.add(addBlockingCell(Sprite.FLOOR_UP_LEFT, new Pair<>(i, 6)));
            for (int i = 28; i <= 28; ++i) m.add(addBlockingCell(Sprite.FLOOR_DOWN_LEFT, new Pair<>(i, 2)));
            for (int i = 6; i <= 6; ++i) m.add(addBlockingCell(Sprite.FLOOR_DOWN_LEFT, new Pair<>(i, 10)));
            for (int i = 24; i <= 24; ++i) m.add(addBlockingCell(Sprite.FLOOR_DOWN_RIGHT, new Pair<>(i, 10)));
/*

            //createBuilding(m, "BUILDING2_", 4, 4, new Pair<>(17, 5), null);
        }

        /**
         * Permet de déterminer, en analysant chacun des sprites entourant un élément, le sprite à placer pour un élément,
         * comme l'arbre ou l'eau (savoir s'il s'agissait du dernier arbre de la ligne et placer le sprite adapté par
         * exemple).
         * @param nbMap carte sur laquelle l'algorithme doit être appliqué
         * @param spriteSet le type de sprite qui doit être adapté à son environnement
         */
        private static void updateSpritesOf(int nbMap, SpriteSet spriteSet){
            for(int i = 0; i <= 31; i++){
                for(int j = 0; j <= 11; ++j){
                    Cell currentCell = getSecondCell(nbMap, i, j);
                    Cell upCell = getSecondCell(nbMap, i, j-1);
                    Cell downCell = getSecondCell(nbMap, i, j+1);
                    Cell rightCell = getSecondCell(nbMap, i+1, j);
                    Cell leftCell = getSecondCell(nbMap, i-1, j);
                    if(currentCell != null && spriteSet.contains(currentCell.getSprite())){
                        if((downCell == null || !spriteSet.contains(downCell.getSprite())) && j!= 11){
                            if((rightCell == null || !spriteSet.contains(rightCell.getSprite())) &&
                                    (leftCell == null || !spriteSet.contains(leftCell.getSprite()))){
                                currentCell.setSprite(spriteSet.getDown());
                            }
                            else if(rightCell != null && spriteSet.contains(rightCell.getSprite()) &&
                            (leftCell != null && spriteSet.contains(leftCell.getSprite())) && j > 0 &&
                                    (upCell == null || !spriteSet.contains(upCell.getSprite()))){
                                currentCell.setSprite(spriteSet.getLeftRight());
                            }
                            else if (upCell != null && spriteSet.contains(upCell.getSprite())){
                                if( rightCell == null || !spriteSet.contains(rightCell.getSprite())){
                                    currentCell.setSprite(spriteSet.getDownRight());
                                }
                                else if(leftCell == null || !spriteSet.contains(leftCell.getSprite())){
                                    currentCell.setSprite(spriteSet.getDownLeft());
                                }
                                else{
                                    currentCell.setSprite(spriteSet.getDownLeftRight());
                                }
                            }
                            else if(j == 0){
                                if(rightCell == null || !spriteSet.contains(rightCell.getSprite())){
                                    currentCell.setSprite(spriteSet.getRight());
                                }
                                else if(leftCell == null || !spriteSet.contains(leftCell.getSprite())){
                                    currentCell.setSprite(spriteSet.getLeft());
                                }
                                else
                                    currentCell.setSprite(spriteSet.getDownLeftRight());
                            }
                            else if(rightCell != null && spriteSet.contains(rightCell.getSprite())){
                                currentCell.setSprite(spriteSet.getLeft());
                            }
                            else{
                                currentCell.setSprite(spriteSet.getRight());
                            }
                        }
                        else if(j-1 >= 0 && (upCell == null || !spriteSet.contains(upCell.getSprite()))){
                            if((rightCell == null || !spriteSet.contains(rightCell.getSprite())) &&
                                    (leftCell == null || !spriteSet.contains(leftCell.getSprite()))){
                                currentCell.setSprite(spriteSet.getUp());
                            }
                            else if((downCell != null && spriteSet.contains(downCell.getSprite()) || j == 11)){
                                if( rightCell == null || !spriteSet.contains(rightCell.getSprite())){
                                    currentCell.setSprite(spriteSet.getUpRight());
                                }
                                else if( leftCell == null || !spriteSet.contains(leftCell.getSprite())){
                                    currentCell.setSprite(spriteSet.getUpLeft());
                                }
                                else{
                                    currentCell.setSprite(spriteSet.getUpLeftRight());
                                }
                            }
                        }
                        else if( i+1 <= 31 && (rightCell == null || !spriteSet.contains(rightCell.getSprite()))){
                            if((upCell == null || !spriteSet.contains(upCell.getSprite())) &&
                                    (downCell == null || !spriteSet.contains(downCell.getSprite()))){
                                currentCell.setSprite(spriteSet.getRight());
                            }
                            else if(upCell != null && spriteSet.contains(upCell.getSprite()) &&
                                    (downCell != null && spriteSet.contains(downCell.getSprite())) && i > 0 &&
                                    (leftCell == null || !spriteSet.contains(leftCell.getSprite()))){
                                currentCell.setSprite(spriteSet.getUpDown());
                            }
                            else if((leftCell == null || !spriteSet.contains(leftCell.getSprite())) && i > 0){
                                currentCell.setSprite(spriteSet.getUpDown());
                            }
                            else{
                                currentCell.setSprite(spriteSet.getRightUpDown());
                            }

                        }
                        else if( i-1 >= 0 && (leftCell == null || !spriteSet.contains(leftCell.getSprite()))){
                            if((upCell == null || !spriteSet.contains(upCell.getSprite())) &&
                                    (downCell == null || !spriteSet.contains(downCell.getSprite()))){
                                currentCell.setSprite(spriteSet.getLeft());
                            }
                            else{
                                currentCell.setSprite(spriteSet.getLeftUpDown());
                            }
                        }
                    }
                }
            }
        }
    

    public static Cell getSecondCell(int nbMap, Integer col, Integer row){
        Map m = getInstance().getMaps().get(nbMap);
        int nb = 0;
        for (Cell cell : m) {
            if(cell.getPosition().getKey().equals(col) && cell.getPosition().getValue().equals(row)){
                if(nb++ == 0) continue;
                return cell;
            }
        }
        return null;
    }
    }


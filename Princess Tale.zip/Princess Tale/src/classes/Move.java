package classes;
import Config.*;
import Player.Player;
import config.Key;
import config.KeyboardConfig;
import config.MapConfig;
import javafx.event.EventHandler;
import javafx.animation.Interpolator;
import javafx.animation.PauseTransition;
import javafx.animation.TranslateTransition;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.util.Duration;
import javafx.util.Pair;
import lib.GameLayout;
import lib.MainLayout;
import lib.Movement;
import classes.*;
import main.GamePanel;




public class Move {
	 private static EventHandler<KeyEvent> setupEventHandler;
	    private static Key lastKeyTyped;

	    private static EventHandler<KeyEvent> stopEventHandler;

	    private Key lastKey;

	    private  Key automatic;
	    private static  boolean stopped = true;

	    private static  boolean directionChanged = false;

	    public static boolean isLastKeyTypedReleased = true;

	    private static AnimationSet animationSet = AnimationSet.PLAYER_STOP;

	    private static  int retard= 300;
		private static EventHandler automaticEventHandler;
	    
	    public  int getRetard() {
	        return Move.retard;
	        
	    }
	    public static boolean isStopped() {
	        return Move.stopped;
	    }

	    public static void setIsLastKeyTypedReleased(boolean isLastKeyTypedReleased) {
	        Move.isLastKeyTypedReleased = isLastKeyTypedReleased;
	    }
	    private static boolean isMovementKey(KeyEvent key){
	        return key.getCode() == Key.UP.getKeyCode() || key.getCode() == Key.DOWN.getKeyCode()||
	                key.getCode() == Key.RIGHT.getKeyCode()|| key.getCode() == Key.LEFT.getKeyCode();
	    }

	    private static EventHandler<KeyEvent> setupMovementEvent(){
	        PauseTransition pt = new PauseTransition();
	        pt.setDuration(Duration.millis(10));
	        pt.setOnFinished(event -> {
	            GamePanel.getSCENE().removeEventHandler(KeyEvent.KEY_PRESSED ,Move.setupEventHandler);
	           GamePanel.getSCENE().addEventHandler(KeyEvent.KEY_PRESSED ,Move.setupEventHandler);
	        });
	        return key -> {
	            if(!Move.isMovementKey(key) ) return;
	            lastKeyTyped = Key.getKeyofKeyCode(key.getCode());
	            if(Move.automaticLastKey != null && Move.automaticLastKey.equals(Move.lastKeyTyped) && !stopped) return;

	            if(isLastKeyTypedReleased)
	                isLastKeyTypedReleased = false;

	            GamePanel.getSCENE().removeEventHandler(KeyEvent.KEY_PRESSED, Move.automaticEventHandler);
	            GamePanel.getSCENE().removeEventHandler(KeyEvent.KEY_PRESSED, Move.setupEventHandler);
	            GamePanel.getSCENE().addEventHandler(KeyEvent.KEY_PRESSED, Move.automaticEventHandler);
	            GamePanel.fireEvent(GamePanel.getSCENE(),new KeyEvent(KeyEvent.KEY_PRESSED, " ", " ", Move.lastKeyTyped.getKeyCode(), false, false, false, false) );
	            pt.play();
	        };
	    }

	    public static void configPlayerEventHandler(Scene scene) {
	    	GamePanel.getSCENE().addEventHandler(KeyEvent.KEY_PRESSED, KeyboardConfig.ENTER.getEventHandler());
	    	GamePanel.getSCENE().addEventHandler(KeyEvent.KEY_PRESSED, KeyboardConfig.ESCAPE.getEventHandler());
	    	GamePanel.getSCENE().addEventHandler(KeyEvent.KEY_PRESSED, KeyboardConfig.TELEPORT.getEventHandler());
	    	GamePanel.getSCENE().addEventHandler(KeyEvent.KEY_PRESSED, KeyboardConfig.CHANGE_SKIN.getEventHandler());
	        Move.setupEventHandler = Move.setupMovementEvent();
	        Move.automaticEventHandler = Move.automaticMovementEvent();
	        Move.stopEventHandler = (event -> {
	            if(lastKeyTyped != null && event.getCode().equals(lastKeyTyped.getKeyCode())){
	                isLastKeyTypedReleased = true;
	            }
	        });

	        scene.removeEventHandler(KeyEvent.KEY_PRESSED ,Move.setupEventHandler);
	        scene.removeEventHandler(KeyEvent.KEY_PRESSED ,Move.automaticEventHandler);
	        scene.addEventHandler(KeyEvent.KEY_PRESSED ,Move.setupEventHandler);
	        scene.addEventHandler(KeyEvent.KEY_RELEASED, stopEventHandler);
	    }
	    //la zone ou la princese se d�place
	    private static Map map = new Map();

	    public static Map getMap() {
	        return Move.map;
	    }

	    public static void setMap(Map map) {
	        Move.map = map;
	    }
	    private static boolean interactionAllowed = false;


		private static Key automaticLastKey;
	    public static boolean isInteractionAllowed() {
	        return Move.interactionAllowed;
	    }
	    //fonction Deplacement de princesse selon mouvement donn�es
	    
	    private static void movePlayer(KeyEvent key){
	        Player player = Player.getINSTANCE();
	        TranslateTransition tt = new TranslateTransition(Duration.millis(Move.retard));

	        boolean isTransitionCell = false;
	        TransitionCell transitionCell = null;
	        if (isTransitionCell(player.getPosition().getKey(), player.getPosition().getValue())) {
	            isTransitionCell = true;
	            transitionCell = getTransitionCell(player.getPosition().getKey(), player.getPosition().getValue());
	        }
	        double x = 0;
	        double y = 0;
	        if (key.getCode() == Key.UP.getKeyCode()) {
	            y = ((player.getPosition().getValue() == 0
	                    || !isAccessibleCell(player.getPosition().getKey(), player.getPosition().getValue() - 1)) ? 0 : -50 );
	            player.setPosition(new Pair<>(
	                    player.getPosition().getKey(),
	                    ((player.getPosition().getValue() == 0
	                            || !isAccessibleCell(player.getPosition().getKey(), player.getPosition().getValue() - 1)) ?
	                            player.getPosition().getValue() : player.getPosition().getValue() - 1)));
	            player.setDirection(Direction.UP);
	            Move.interactionAllowed = true;
	        }
	        if (key.getCode() == Key.DOWN.getKeyCode()) {
	            y = (player.getPosition().getValue() == Layout.getINSTANCE().getNbRows() - 1
	                    || !isAccessibleCell(player.getPosition().getKey(), player.getPosition().getValue() + 1) ? 0 : 50 );
	            player.setPosition(new Pair<>(
	                    player.getPosition().getKey(),
	                    player.getPosition().getValue() == Layout.getINSTANCE().getNbRows() - 1
	                            || !isAccessibleCell(player.getPosition().getKey(), player.getPosition().getValue() + 1) ?
	                            player.getPosition().getValue() : player.getPosition().getValue() + 1));
	            player.setDirection(Direction.DOWN);
	            Move.interactionAllowed = true;
	        }
	        if (key.getCode() == Key.RIGHT.getKeyCode()) {
	            x = (player.getPosition().getKey() == Layout.getINSTANCE().getNbCols() - 1
	                    || !isAccessibleCell(player.getPosition().getKey() + 1, player.getPosition().getValue()) ? 0 : 50 );
	            player.setPosition(new Pair<>(
	                    player.getPosition().getKey() == Layout.getINSTANCE().getNbCols() - 1
	                            || !isAccessibleCell(player.getPosition().getKey() + 1, player.getPosition().getValue()) ?
	                            player.getPosition().getKey() : player.getPosition().getKey() + 1,
	                    player.getPosition().getValue()));
	            player.setDirection(Direction.RIGHT);
	            Move.interactionAllowed = true;
	        }
	        if (key.getCode() == Key.LEFT.getKeyCode()) {
	            x = (player.getPosition().getKey() == 0
	                    || !isAccessibleCell(player.getPosition().getKey() - 1, player.getPosition().getValue()) ? 0 : -50 );
	            player.setPosition(new Pair<>(
	                    player.getPosition().getKey() == 0
	                            || !isAccessibleCell(player.getPosition().getKey() - 1, player.getPosition().getValue()) ?
	                            player.getPosition().getKey() : player.getPosition().getKey() - 1,
	                    player.getPosition().getValue()));
	            player.setDirection(Direction.LEFT);
	            Move.interactionAllowed = true;
	        }
	        if (key.getCode() != Key.ENTER.getKeyCode()){
	         DialogPanel.getINSTANCE().removeContent();
	        }
	        refreshPlayerSprite();
	      //  Cell cell = MapConfig.getSecondCell(MapConfig.getINSTANCE().getMaps().indexOf(map), player.getPosition().getKey(), player.getPosition().getValue());

	        if(Move.isMovementKey(key)){
	            Move.automaticLastKey = Key.getKeyofKeyCode(key.getCode());
	        }

	        if (isTransitionCell && transitionCell.getDirection().equals(player.getDirection())) {
	            Layout.getScene().addEventHandler(KeyEvent.KEY_PRESSED, transitionCell.getEventHandler());
	        } else {

	            ImageView imageView = player.getImage();
	            tt.setNode(imageView);
	            tt.setByX(x);
	            tt.setByY(y);
	            tt.setInterpolator(Interpolator.LINEAR);

	            tt.play();
	        }}
	        //changer les Sprite de EVALINA 
	         
	        private static void refreshPlayerSprite(){
	            Player princess = Player.getINSTANCE();
	            switch (princess.getDirection()){
	                case UP:
	                	princess.setSprite(AnimationSet.getUp());
	                    break;
	                case DOWN:
	                	princess.setSprite(AnimationSet.getDown());
	                    break;
	                case RIGHT:
	                	princess.setSprite(AnimationSet.getRight());
	                    break;
	                case LEFT:
	                	princess.setSprite(AnimationSet.getLeft());
	                    break;
	            }
	        }
	         


	
	        public static void setInteractionAllowed(boolean interactionAllowed) {
	            Move.interactionAllowed = interactionAllowed;
	        }

	        public static AnimationSet getAnimationSet() {
	            return Move.animationSet;
	        }
	        public static void removeMovement(){
	            Layout.getINSTANCE().getPane().setFocusTraversable(false);
	            Layout.getScene().removeEventHandler(KeyEvent.KEY_PRESSED, Move.setupEventHandler);
	        }
			public static void resumeMovement() {
				Layout.getINSTANCE().getPane().setFocusTraversable(true);
		        Layout.getINSTANCE().getPane().requestFocus();
		        Layout.getScene().addEventHandler(KeyEvent.KEY_PRESSED, Move.setupEventHandler);
				
			}
			
			
		    private static EventHandler<KeyEvent> automaticMovementEvent(){

		        PauseTransition pt = new PauseTransition();
		        pt.setDuration(Duration.millis(Move.retard));
		        pt.setOnFinished(event -> {

		            if(directionChanged){
		                Move.automaticLastKey = Move.lastKeyTyped;
		                Layout.getScene().addEventHandler(KeyEvent.KEY_PRESSED, Move.automaticEventHandler);
		                KeyEvent.fireEvent(Layout.getScene(),new KeyEvent(KeyEvent.KEY_PRESSED, " ", " ", Move.automaticLastKey.getKeyCode(), false, false, false, false) );
		                directionChanged = false;
		                return;
		            }

		            if(isLastKeyTypedReleased){
		                animationSet = animationSet.getStopAnimationSet();
		                Player.getINSTANCE().setSprite(animationSet.getSpriteDirection(Player.getINSTANCE().getDirection()));
		                stopped = true;
		                return;
		            }
		            else {
		                Layout.getScene().addEventHandler(KeyEvent.KEY_PRESSED, Move.automaticEventHandler);
		                KeyEvent.fireEvent(Layout.getScene(),new KeyEvent(KeyEvent.KEY_PRESSED, " ", " ", Move.automaticLastKey.getKeyCode(), false, false, false, false) );
		            }
		        });
		        return key -> {

		            if(!stopped && !Move.automaticLastKey.equals(Move.lastKeyTyped)){
		                Layout.getScene().removeEventHandler(KeyEvent.KEY_PRESSED, Move.automaticEventHandler);
		                stopped = false;
		                animationSet = AnimationSet.getAnimationSet(AnimationSet.getNbAnim(Math.floorDiv(
		                        AnimationSet.getAnimationSetThatHave( Player.getINSTANCE().getSprite()).ordinal(), 4)));
		                directionChanged = true;
		               Layout.getScene().removeEventHandler(KeyEvent.KEY_PRESSED, Move.automaticEventHandler);
		                pt.play();
		                return;
		            }

		            animationSet = AnimationSet.getAnimationSet(AnimationSet.getNbAnim(Math.floorDiv(
		                    AnimationSet.getAnimationSetThatHave( Player.getINSTANCE().getSprite()).ordinal(), 4)));
		            movePlayer(key);
		            stopped = false;

		            Layout.getScene().removeEventHandler(KeyEvent.KEY_PRESSED, Move.automaticEventHandler);
		            pt.play();
		        };
		    }
		    
		    private static boolean isAccessibleCell(Integer col, Integer row){
		        while(Move.map.getBlockingCellIterator().hasNext()){
		            Block  blockingCell = Move.map.getBlockingCellIterator().next();
		            if(blockingCell.getPosition().getKey().equals(col) && blockingCell.getPosition().getValue().equals(row)){
		                Move.map.getBlockingCellIterator().reset();
		                return false;
		            }
		        }
		        return true;
		        
		    }   
		    private static boolean isTransitionCell(Integer col, Integer row){
		        while(Move.map.getTransitionCellIterator().hasNext()){
		            TransitionCell transitionCell = Move.map.getTransitionCellIterator().next();
		            if(transitionCell.getPosition().getKey().equals(col) && transitionCell.getPosition().getValue().equals(row)){
		                Move.map.getTransitionCellIterator().reset();
		                return true;
		            }
		        }
		        return false;
		    }
		    

		    private static TransitionCell getTransitionCell(Integer col, Integer row){
		        for (Cell cell : Move.map ) {
		            if(cell.getPosition().getKey().equals(col) && cell.getPosition().getValue().equals(row)){
		                if(cell instanceof TransitionCell)
		                    return (TransitionCell) cell;
		            }
		        }
		        return null;
		    }
		    

	    
}

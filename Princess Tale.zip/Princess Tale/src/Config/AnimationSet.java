package Config;

import config.Direction;
import config.Sprite;

public enum AnimationSet {
	
	 
    PLAYER_MOVE_RIGHT(Sprite.PLAYER_UP_MOVE_RIGHT, Sprite.PLAYER_DOWN_MOVE_RIGHT, Sprite.PLAYER_RIGHT_MOVE_RIGHT, Sprite.PLAYER_LEFT_MOVE_RIGHT),
    PLAYER_STOP2(Sprite.PLAYER_UP_STOP, Sprite.PLAYER_DOWN_STOP, Sprite.PLAYER_RIGHT_STOP, Sprite.PLAYER_LEFT_STOP),
    PLAYER_MOVE_LEFT(Sprite.PLAYER_UP_MOVE_LEFT, Sprite.PLAYER_DOWN_MOVE_LEFT, Sprite.PLAYER_RIGHT_MOVE_LEFT, Sprite.PLAYER_LEFT_MOVE_LEFT),
    PLAYER_STOP(Sprite.PLAYER_UP_STOP, Sprite.PLAYER_DOWN_STOP, Sprite.PLAYER_RIGHT_STOP, Sprite.PLAYER_LEFT_STOP);
	
    private static Sprite up;
	private static Sprite down;
	private static  Sprite right;
	private static Sprite left;
    private static int nbAnim = 0;
    private static final int NB_MAX_ANIM = 5;
    AnimationSet(Sprite up, Sprite down, Sprite right, Sprite left) {
        up = up;
        down = down;
        right = right;
        left = left;
    }
    
	public static int getNbAnim() {
		return nbAnim;
	}
	public static void setNbAnim(int nbAnim) {
		AnimationSet.nbAnim = nbAnim;
	}
	public static Sprite getUp() {
		return up;
	}
	public void setUp(Sprite up) {
		this.up = up;
	}
	public static Sprite getDown() {
		return down;
	}
	public void setDown(Sprite down) {
		this.down = down;
	}
	public static Sprite getRight() {
		return right;
	}
	public void setRight(Sprite right) {
		this.right = right;
	}
	public static Sprite getLeft() {
		return left;
	}
	public void setLeft(Sprite left) {
		this.left = left;
	}
    	//Direction Sprite
	   public Direction getDirection(Sprite sprite){
	        if(sprite.equals(this.up))
	            return Direction.UP;
	        if(sprite.equals(this.down))
	            return Direction.DOWN;
	        if(sprite.equals(this.right))
	            return Direction.RIGHT;
	        if(sprite.equals(this.left))
	            return Direction.LEFT;
	        return null;
	    }
	   // Direction correspondante au Sprite 
	    public Sprite getSpriteDirection(Direction direction){
	        switch (direction){
	            case UP:
	                return this.up;
	            case DOWN:
	                return this.down;
	            case RIGHT:
	                return this.right;
	            case LEFT:
	                return this.left;
	        }
	        return null;
	    }
	     

	    
	    public static AnimationSet getAnimationSetThatHave(Sprite sprite){
	        for(int i = 0; i < AnimationSet.values().length; ++i){
	            if(AnimationSet.values()[i].contains(sprite))
	                return AnimationSet.values()[i];
	        }
	        return null;
	    }
	    
	    private boolean contains(Sprite sprite){
	        return sprite.equals(this.up) || sprite.equals(this.down) || sprite.equals(this.left) || sprite.equals(this.right);
	    }
	    
	    public AnimationSet getStopAnimationSet(){
	        return AnimationSet.values()[Math.floorDiv(this.ordinal(), AnimationSet.NB_MAX_ANIM) * AnimationSet.NB_MAX_ANIM + 1];
	    }
	    
	    public static int getNbAnim(int nbAnimSet) {
	        AnimationSet.nbAnim = (AnimationSet.nbAnim % AnimationSet.NB_MAX_ANIM == AnimationSet.NB_MAX_ANIM - 1) ? 0 : ++AnimationSet.nbAnim;
	        return nbAnimSet * AnimationSet.NB_MAX_ANIM + AnimationSet.nbAnim;
	    }
	    
	    public static AnimationSet getAnimationSet(int nb){
	        if(nb < 0 || nb >= AnimationSet.values().length)
	            return null;
	        return AnimationSet.values()[nb];
	    }
	    
	
}

package Config;

import classes.*;


public enum MapArrangement {
  //Enum�ration de toutes les cartes du jeu
	//Carte chateau 
	
	Map1(Castle.NORTH.getMaps().get(2),Castle.NORTH.getMaps().get(1),null,null);
	
	
    private Map up;

    private Map down;

    private Map right;

    private Map left;
    
    MapArrangement(Map up, Map down, Map right, Map left) {
        this.up = up;
        this.down = down;
        this.right = right;
        this.left = left;
    }
    



    public Map getUp() {
        return up;
    }


    public Map getDown() {
        return down;
    }

 
    public Map getRight() {
        return right;
    }


    public Map getLeft() {
        return left;
    }
}

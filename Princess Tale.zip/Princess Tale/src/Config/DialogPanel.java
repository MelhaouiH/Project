package Config;
import classes.Layout;
import classes.Move;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.Background;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;

import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;

//enum�ration des dialogues du jeu 
public class DialogPanel {
	 private static Text text;
	 private VBox buttons;
	 private GridPane gridPane;
	 private static final DialogPanel INSTANCE = new DialogPanel();
	 
	 public DialogPanel()
	 {
		 this.text = new Text();
	        this.text.setWrappingWidth((float) (Layout.getWidth()*2/3)*2/3);
	        this.text.setTextAlignment(TextAlignment.JUSTIFY);
	        this.text.setFont(Font.font("TimesRoman"));
	        this.text.setFill(Color.WHITE);
	        VBox pane = new VBox();
	        pane.getChildren().add(this.text);
	        pane.setAlignment(Pos.CENTER);
	        pane.setPadding(new Insets(50));
	        GridPane.setConstraints(pane, 0, 0);

	       
	        VBox pane1 = new VBox();
	        pane1.setAlignment(Pos.CENTER);
	        Text text = new Text();
	        text.setFill(Color.WHITE);

	        pane1.getChildren().add(text);
	        GridPane.setConstraints(pane1, 1, 1 );

	        this.buttons = new VBox();
	        this.buttons.setSpacing(1);
	        this.buttons.setAlignment(Pos.CENTER);
	        GridPane.setConstraints(this.buttons, 1, 0 );

	        this.gridPane = new GridPane();
	        this.gridPane.setBackground(new Background(new BackgroundFill(Color.BLACK, CornerRadii.EMPTY, Insets.EMPTY)));

	        this.gridPane.getChildren().add(pane);
	        this.gridPane.getChildren().add(pane1);
	        this.gridPane.getChildren().add(this.buttons);
	        this.gridPane.getColumnConstraints().add(new ColumnConstraints(  (float)(Layout.getWidth()*2/3)*2/3));
	        this.gridPane.getColumnConstraints().add(new ColumnConstraints(  (float)(Layout.getWidth()*2/3)/3));
	        this.gridPane.getRowConstraints().add(new RowConstraints(  (float)(Layout.getHeight()/3)*2/3));
	        this.gridPane.getRowConstraints().add(new RowConstraints(  (float)(Layout.getHeight()/3)/3));
	 }
	 
	   public GridPane getGridPane() {
	        return this.gridPane;
	    }

	    /**
	     * Renvoie l'instance de DialogLayout.
	     * @return DialogLayout
	     */
	    public static DialogPanel getINSTANCE() {
	        return DialogPanel.INSTANCE;
	    }

	    /**
	     * Setter du texte de la boîte de dialogue.
	     * @param string texte de la boîte de dialogue
	     */
	    public void setText(String string){
	        this.text.setText(string);
	    }

	    /**
	     * Réinitialise le contenu de la boîte de dialogue.
	     */
	    public void removeContent(){
	        this.text.setText("");
	        this.buttons.getChildren().remove(0, this.buttons.getChildren().size());
	    }

	    /**
	     * Ajoute un nouveau bouton à la VBox.
	     * @param text2 texte du bouton
	     * @param eventHandler événement associé au bouton
	     */
	    public void addButton(String text2, EventHandler<ActionEvent> eventHandler){
	        Button button = new Button(text2);
	        button.setOnAction(eventHandler);
	        button.setScaleY(0.8);
	        button.setScaleX(0.8);
	        button.getStyleClass().add("interact_button");
	        button.focusedProperty().addListener((observable, oldValue, newValue) -> button.setStyle(observable.getValue() ? "-fx-background-color: lightgrey;" : ""));

	        this.buttons.getChildren().add(button);

	        Move.removeMovement();
	        if(this.buttons.getChildren().size() == 1){
	            button.requestFocus();
	        }
	    }

	    // Ajoute un bouton de retour  la VBox.
	    
	    public void addReturnButton(){
	        if(this.buttons.getChildren().isEmpty())
	            return;
	        Button button = new Button("Retour");
	        button.setScaleY(0.8);
	        button.setScaleX(0.8);
	        button.setOnAction(Action.RETURN.getEventHandler());
	        button.setCancelButton(true);
	        button.getStyleClass().add("interact_button");
	        button.focusedProperty().addListener((observable, oldValue, newValue) -> button.setStyle(observable.getValue() ? "-fx-background-color: lightgrey" : ""));

	        this.buttons.getChildren().addAll(button);

	        Move.removeMovement();
	    }

		public static Text getText() {
			return text;
		}

		public void setText(Text text) {
			this.text = text;
		}



}

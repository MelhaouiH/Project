package Config;

import classes.Dialog;
import classes.Move;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;


public enum Action { 
  //toutes les actions disponibles dans le jeu
	
    // Action du bouton Retour
    RETURN,
    ;
	   private EventHandler<ActionEvent> eventHandler;


	    public EventHandler<ActionEvent> getEventHandler() {
	        return eventHandler;
	    }
	    static { 
    // Action du bouton Retour
    RETURN.eventHandler = ((EventHandler<ActionEvent>) (action) -> {
        DialogPanel.getINSTANCE().removeContent();
        Move.resumeMovement();
        Move.setInteractionAllowed(true);
    });
}
}

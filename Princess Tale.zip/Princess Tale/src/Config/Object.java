package Config;

import javafx.scene.image.ImageView;
import javafx.util.Pair;

public enum Object {
	// Enum�ration des objets disponibles dans l'inventaire.
	
	OBJ1("Plaque de tôle", new ImageView("sprite/object/"), new Pair<>(0,0)),
    OBJ2("Réacteurs endommagés", new ImageView("sprite/object/"), new Pair<>(1,0)),
    OBJ2_2("Réacteurs", new ImageView("sprite/object/"), new Pair<>(1,0));
	   //Nom de l'objet
	
	    private String name;

	    private ImageView imageView;

	    private Pair<Integer, Integer> inventoryPosition;


	    Object(String name, ImageView imageView, Pair<Integer, Integer> inventoryPosition) {
	        this.name = name;
	        this.imageView = imageView;
	        this.imageView.setPreserveRatio(true);
	        this.imageView.setFitWidth(100);
	        this.inventoryPosition = inventoryPosition;
	    }

	    public String getName() {
	        return this.name;
	    }

	    public ImageView getImageView() {
	        return this.imageView;
	    }

	    public Pair<Integer, Integer> getInventoryPosition() {
	        return inventoryPosition;
	    }
	}

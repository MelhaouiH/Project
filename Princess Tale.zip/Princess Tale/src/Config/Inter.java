package Config;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import classes.*;
import config.Action;
import config.DialogConfig;
import config.Interaction;
import config.KeyboardConfig;
import config.MapConfig;
import config.Object;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.util.Pair;
import lib.BlockingCell;
import lib.Cell;
import lib.DialogLayout;
import lib.Inventory;
import lib.MainLayout;
import lib.Movement;
public enum Inter {

    //Interaction de retour au jeu
    RETURN_GAME;
	 private static EventHandler<KeyEvent> eventHandler;
	   public static EventHandler<KeyEvent> getEventHandler() {
	        return eventHandler;
	    }
	   static {	   
		   
	     // Interaction permettant de revenir au jeu
		   
       RETURN_GAME.eventHandler = (event -> {
           if(event.getCode() == Key.SPACE.getKeyCode()){
               Layout.getScene().setRoot(Layout.getINSTANCE().getGridPane());
               Move.resumeMovement();
           }
       });
}


	public void setEventHandler(EventHandler<KeyEvent> eventHandler) {
		this.eventHandler = eventHandler;
	}

	private static EventHandler<KeyEvent> createSimpleDialog(Inter interaction, Dialog dialogConfig){
	        return (event -> {
	            if(event.getCode() == KeyboardConfig.ENTER.getKey().getKeyCode() && Move.isInteractionAllowed()){
	                 Move.setInteractionAllowed(false);
	                DialogPanel.getINSTANCE().setText(dialogConfig.getText());
	                interaction.setInteractionDone(true);
	            }
	            Layout.getScene().removeEventHandler(KeyEvent.KEY_PRESSED, Inter.getEventHandler());
	        });
	    }
	
    /*Creation d'un interaction pour une �nigme  ! IMPORTAAANT */
    private static EventHandler<KeyEvent> createRiddleInteraction(Inter interaction, DialogPanel dialogBefore, DialogPanel dialogAfter, Dialog dialogButton1, Dialog dialogButton2, Dialog dialogButton3, Action actionError, Action actionSuccess){
        return (event -> {
            if(event.getCode() == KeyboardConfig.ENTER.getKey().getKeyCode()){
                if(!Inter.isInteractionDone()){
                    DialogPanel.getINSTANCE().setText(dialogBefore.getText());
                    DialogPanel.getINSTANCE().addButton(dialogButton1.getText(), actionError.getEventHandler());
                    DialogPanel.getINSTANCE().addButton(dialogButton2.getText(), actionSuccess.getEventHandler());
                    DialogPanel.getINSTANCE().addButton(dialogButton3.getText(), actionError.getEventHandler());
                    VBox vbox = (VBox) DialogPanel.getINSTANCE().getGridPane().getChildren().get(2);
                    List<Node> list = new ArrayList<>(vbox.getChildren());
                    Collections.shuffle(list);
                    vbox.getChildren().removeAll(list);
                    vbox.getChildren().addAll(list);
                    DialogPanel.getINSTANCE().addReturnButton();
                }
                else{
                    DialogPanel.getINSTANCE().setText(dialogAfter.getText());
                }
            }
            Layout.getScene().removeEventHandler(KeyEvent.KEY_PRESSED, Inter.getEventHandler());
        });
    }
    //une interaction mettant en place un dialogue et un bouton permettant de r�cup�rer ou de donner un �l�ment.
   
   private static EventHandler<KeyEvent> createSimpleButtonInteractionObjectWithInteractionChange(Inter interaction, Dialog dialogConfigBefore, Dialog dialogConfigAfter, Dialog dialogConfigButton, Action action, boolean contains, Object object, int nbMap, Inter toRemove, Inter toAdd){
       return (event -> {
           if(event.getCode() == KeyboardConfig.ENTER.getKey().getKeyCode() && Move.isInteractionAllowed()){
               Move.setInteractionAllowed(false);
               if(!Inter.isInteractionDone()){
                   DialogPanel.getINSTANCE().setText(dialogConfigBefore.getText());
                   if(contains == Inventory.getINSTANCE().contains(object)){
                       DialogPanel.getINSTANCE().addButton(dialogConfigButton.getText(), action.getEventHandler());
                       DialogPanel.getINSTANCE().addReturnButton();
                   }
               }
               else{
                   DialogPanel.getINSTANCE().setText(dialogConfigAfter.getText());
               }
           
           }
          Layout.getScene().removeEventHandler(KeyEvent.KEY_PRESSED, interaction.getEventHandler());
       });
   }


	public static GridPane getINSTANCE() {
		// TODO Auto-generated method stub
		return null;
	}


   private static boolean interactionDone = false;

   public static boolean isInteractionDone() {
       return interactionDone;
   }

public void setInteractionDone(boolean interactionDone) {
	this.interactionDone = interactionDone;
}


		   
	   }

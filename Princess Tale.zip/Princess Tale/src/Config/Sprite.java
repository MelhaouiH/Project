package Config;

public enum Sprite {
	//Pour la princesse
    PLAYER_UP_STOP("sprite/player/player_up_stop.png"),
    PLAYER_UP_MOVE_RIGHT("sprite/player/player_up_move_right.png"),
    PLAYER_UP_MOVE_LEFT("sprite/player/player_up_move_left.png"),
    PLAYER_DOWN_STOP("sprite/player/player_down_stop.png"),
    PLAYER_DOWN_MOVE_RIGHT("sprite/player/player_down_move_right.png"),
    PLAYER_DOWN_MOVE_LEFT("sprite/player/player_down_move_left.png"),
    PLAYER_RIGHT_STOP("sprite/player/player_right_stop.png"),
    PLAYER_RIGHT_MOVE_RIGHT("sprite/player/player_right_move_right.png"),
    PLAYER_RIGHT_MOVE_LEFT("sprite/player/player_right_move_left.png"),
    PLAYER_LEFT_STOP("sprite/player/player_left_stop.png"),
    PLAYER_LEFT_MOVE_RIGHT("sprite/player/player_left_move_right.png"),
    PLAYER_LEFT_MOVE_LEFT("sprite/player/player_left_move_left.png");
    
    private String spriteWay;
    Sprite(String spritePath) {
        this.spriteWay = spriteWay;
    }
    
    public String getSpriteWay() {
        return this.spriteWay;
    }
}

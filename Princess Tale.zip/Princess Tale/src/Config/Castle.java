package Config;

import java.util.ArrayList;

import java.util.Arrays;
import java.util.Collections;

import classes.*;
import config.Planet;
import lib.Map;




public enum Castle {
	 CAST("Chateau", new ArrayList<>(Arrays.asList( new Map(), new Map(), new Map()))),
	 HALL("Hall Principale", new ArrayList<>(Arrays.asList( new Map(), new Map(), new Map(), new Map()))),
	 NORTH("Aile Nord ", new ArrayList<>(Arrays.asList( new Map(), new Map(), new Map()))),
	 WEST("Aile Sud", new ArrayList<>(Arrays.asList( new Map(), new Map()))),
	 OUEST("Aile Est", new ArrayList<>(Arrays.asList( new Map(), new Map(), new Map()))),
	 SOUTH("Aile Ouest", new ArrayList<>(Arrays.asList( new Map(), new Map(), new Map())));

	
    private String name;
    private ArrayList<Map> maps;
    public ArrayList<Map> getMaps() {
        return this.maps;
    }
    Castle(String name, ArrayList<Map> maps) {
        this.name = name;
        this.maps = maps;
    }
    public static Castle getHallOfMap(classes.Map map){
        for(Castle castle : Castle.values())
            if(castle.getMaps().contains(map))
                return castle;
        return null;
    }

}

package main;

import javax.swing.JFrame;

import javafx.application.Application;
import javafx.application.Platform;

import config.Sprite;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import classes.*;

public class Game extends Application {

    private static Stage stage;


	@Override
	public void start(Stage PS) {
        stage = PS;
        PS.setTitle("Princess tail");
        Scene scene = GamePanel.getSCENE();
        scene.setRoot(GamePanel.getINSTANCE().getvBox());
        PS.setScene(scene);
        PS.getIcons().add(new Image(Sprite.PLAYER_DOWN_STOP.getSpritePath()));
        PS.show();
	}
    public static Stage getStage() {
        return Game.stage;
    }
	public static void main (String []  args)
	{
	    
	        launch(args);
	    
		
	}

}

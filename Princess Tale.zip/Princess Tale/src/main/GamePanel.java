 package main;
import classes.Layout;



import config.*;
import javafx.animation.PauseTransition;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.StringProperty;
import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.concurrent.Worker;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.util.Duration;


public class GamePanel  {
	
	// dimensions
	public static final int WIDTH = 320;
	public static final int HEIGHT = 500;
	public static final int SCALE = 2;


	    private static VBox vBox,options;

	    private static Service<Void> testService;

	    private static Stage loadingStage;

	    private static boolean isButtonChanging = false;

	    private static final Scene SCENE = new Scene(new Parent(){},WIDTH, HEIGHT);

	    private static GamePanel INSTANCE = new GamePanel();

	    public GamePanel() {
	    	GamePanel.vBox = new VBox();
	    	GamePanel.vBox.setAlignment(Pos.CENTER);
	    	GamePanel.vBox.setSpacing(10);
	    	GamePanel.vBox.setBackground(new Background(new BackgroundImage(new Image(Sprite.BACKGROUND_LAUNCHER.getSpritePath()),
	                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, BackgroundSize.DEFAULT)));
	    	GamePanel.getSCENE().addEventHandler(KeyEvent.KEY_PRESSED, event -> {
	            if(event.getCode() == KeyCode.ENTER && GamePanel.getSCENE().getFocusOwner() instanceof Button){
	                ((Button) GamePanel.getSCENE().getFocusOwner()).fire();
	            }
	            if(event.getCode() == KeyCode.ESCAPE && !isButtonChanging){
	            	GamePanel.SCENE.setRoot(GamePanel.vBox);
	            }
	        });
	    	GamePanel.setupLauncher();
	    }

	    public static void setupLauncher(){
	        Button game = new Button();

	        setupLoadingLayout();

	        game.setOnAction(event -> {
	            Button button = (Button) event.getSource();
	            if(button.getText().equals("Reprendre la partie")){
	            	Layout.getSTAGE().show();
	            }
	            else{
	                loadingStage.show();
	                GamePanel.getSCENE().setRoot(Layout.getINSTANCE().getGridPane());
	                if(testService.stateProperty().equals(Worker.State.SUCCEEDED)){
	                    System.out.println("OK");
	                    testService.restart();
	                }
	                else{
	                    testService.restart() ;
	                }

	            }
	        });
	        Button options = new Button("Options");
	        options.setOnAction(event -> GamePanel.SCENE.setRoot(GamePanel.getOptions()));
	        Button quit = new Button("Quitter");
	        quit.setOnAction(event -> {
	            Stage s = (Stage) GamePanel.SCENE.getWindow();
	            s.close();
	        });
	        GamePanel.vBox.getChildren().removeAll(GamePanel.vBox.getChildren());
	        GamePanel.vBox.getChildren().addAll(game, options,  quit);
	    }

	    private static void setupLoadingLayout(){
	        loadingStage = new Stage();
	        loadingStage.getIcons().add(new Image(Sprite.PLAYER_DOWN_STOP.getSpritePath()));
	        GamePanel.testService = new Service<Void>() {
	            @Override
	            protected Task<Void> createTask() {
	                return MapConfig.getTask();
	            }
	        };

	        ProgressBar progressBar = new ProgressBar();
	        progressBar.progressProperty().bind(testService.progressProperty());

	        Text text = new Text();
	        Text percent = new Text();
	        text.textProperty().bind(testService.messageProperty());
	        percent.textProperty().bind(StringProperty.stringExpression(IntegerProperty.integerExpression(testService.progressProperty().multiply(100))).concat("%"));

	        BorderPane pane = new BorderPane();
	        VBox pane2 = new VBox();
	        pane2.setSpacing(5);
	        pane2.setAlignment(Pos.CENTER);
	        pane.setBackground(new Background( new BackgroundImage(new Image(Sprite.LOAD.getSpritePath()), BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, BackgroundSize.DEFAULT)));
	        pane2.setBackground(new Background(new BackgroundFill(Color.color(0.6,0.6,0.6, 0.7), new CornerRadii(30), new Insets(-10, 350, -10, 350))));
	        loadingStage.setScene(new Scene(pane, 900, 600));
	        pane2.getChildren().addAll(progressBar, percent, text );

	        BorderPane.setAlignment(text, Pos.BOTTOM_CENTER);
	        pane.setBottom(pane2);

	        testService.setOnFailed(event -> testService.getException().printStackTrace());
	        testService.setOnSucceeded(event -> {
	            CinematicConfig.setupGame();
	           Layout.getSTAGE().setTitle("La Princesse EVALINA");
	            Layout.getSTAGE().setOnCloseRequest(event1 -> GamePanel.setupLauncher());
	            loadingStage.close();
	            Layout.getSTAGE().show();
	        });
	    }




	    private static VBox getOptions(){
	        PauseTransition pt = new PauseTransition();
	        PauseTransition pt1 = new PauseTransition();
	        pt.setDuration(Duration.millis(1));
	        pt1.setDuration(Duration.millis(100));
	        GamePanel.options = new VBox();
	        Text text = new Text("Chagement de touches");
	        text.setFill(Color.WHITE);
	        GamePanel.options.getChildren().add(text);
	        for(int i = 0; i < Key.values().length; ++i){
	            HBox hBox = new HBox();
	            Key currentKey = Key.values()[i] ;
	            Text name = new Text(currentKey.name() + " : " + currentKey.getKeyCode().getName());
	            name.setFill(Color.WHITE);
	            Button button = new Button("Changer" );
	            button.setScaleY(0.8);
	            button.setScaleX(0.8);
	           EventHandler<KeyEvent> keyEventEventHandler = new EventHandler<KeyEvent>() {
	               @Override
	               public void handle(KeyEvent key) {
	                   if(Key.isKeyCodeAlreadyUsed(key.getCode())){
	                       Key.getKeyofKeyCode(key.getCode()).setKeyCode(KeyCode.UNDEFINED);
	                      
	                   }
	                   currentKey.setKeyCode(key.getCode());
	                   name.setText(currentKey.name() + " : " + currentKey.getKeyCode().getName());
	                   hBox.getChildren().get(1).requestFocus();
	                   text.setText("Changement de touches");
	                   isButtonChanging = false;
	                   GamePanel.getSCENE().removeEventHandler(KeyEvent.KEY_PRESSED, this);
	               }
	           };
	            button.setOnAction(event -> {
	                pt.play();
	                pt.setOnFinished(event1 -> {
	                    text.setText("Appuyez sur une touche pour : " + currentKey.name());
	                    isButtonChanging = true;
	                    GamePanel.getSCENE().getRoot().requestFocus();
	                    GamePanel.getSCENE().addEventHandler(KeyEvent.KEY_PRESSED, keyEventEventHandler);
	                });
	            });
	            hBox.getChildren().addAll(name, button);
	            hBox.setAlignment(Pos.CENTER);
	            hBox.setSpacing(10);


	            GamePanel.options.getChildren().add(hBox);
	        }
	        GamePanel.options.getChildren().add(GamePanel.getReturnButon());
	        GamePanel.options.setAlignment(Pos.CENTER);
	        GamePanel.options.setSpacing(1);
	        GamePanel.options.getChildren().forEach((child) -> child.setTranslateY(50));
	        GamePanel.options.setBackground(new Background(new BackgroundImage(new Image(Sprite.BACKGROUND_OPTIONS.getSpritePath()),
	                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, BackgroundSize.DEFAULT)));
	        return GamePanel.options;
	    }


	    private static Button getReturnButon(){
	        Button button = new Button("Retour");
	        button.setOnAction(event -> GamePanel.SCENE.setRoot(GamePanel.vBox));
	        button.setAlignment(Pos.BOTTOM_CENTER);
	        return button;
	    }

	    public VBox getvBox() {
	        return GamePanel.vBox;
	    }

	    /**
	     * Getter de la scène du lanceur du jeu.
	     * @return Scene
	     */
	    public static Scene getSCENE() {
	        return GamePanel.SCENE;
	    }

	    /**
	     * Getter de l'instance du lanceur du jeu.
	     * @return LauncherLayout
	     */
	    public static GamePanel getINSTANCE() {
	        return GamePanel.INSTANCE;
	    }


		

		public static void fireEvent(Scene scene2, KeyEvent keyEvent) {
			// TODO Auto-generated method stub
			
		}
	}
